package com.tencent.beacontbs.a;

import java.util.Observable;

public final class g
  extends Observable
{
  public final void setChanged()
  {
    super.setChanged();
  }
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\beacontbs\a\g.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */