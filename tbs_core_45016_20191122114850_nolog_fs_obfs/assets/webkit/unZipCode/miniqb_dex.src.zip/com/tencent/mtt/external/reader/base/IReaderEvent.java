package com.tencent.mtt.external.reader.base;

public abstract interface IReaderEvent
{
  public abstract boolean onUiEvent(int paramInt, Object paramObject1, Object paramObject2);
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\mtt\external\reader\base\IReaderEvent.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */