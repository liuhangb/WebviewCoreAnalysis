package com.tencent.mtt.browser.engine;

import android.content.Intent;

public abstract interface AppBroadcastObserver
{
  public abstract void onBroadcastReceiver(Intent paramIntent);
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\mtt\browser\engine\AppBroadcastObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */