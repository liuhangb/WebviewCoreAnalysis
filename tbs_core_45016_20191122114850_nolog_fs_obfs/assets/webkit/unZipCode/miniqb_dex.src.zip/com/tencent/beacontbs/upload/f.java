package com.tencent.beacontbs.upload;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;

final class f
{
  HttpResponse jdField_a_of_type_OrgApacheHttpHttpResponse = null;
  HttpClient jdField_a_of_type_OrgApacheHttpClientHttpClient = null;
  HttpPost jdField_a_of_type_OrgApacheHttpClientMethodsHttpPost = null;
  
  public f(HttpResponse paramHttpResponse, HttpPost paramHttpPost, HttpClient paramHttpClient)
  {
    this.jdField_a_of_type_OrgApacheHttpHttpResponse = paramHttpResponse;
    this.jdField_a_of_type_OrgApacheHttpClientMethodsHttpPost = paramHttpPost;
    this.jdField_a_of_type_OrgApacheHttpClientHttpClient = paramHttpClient;
  }
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\beacontbs\upload\f.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */