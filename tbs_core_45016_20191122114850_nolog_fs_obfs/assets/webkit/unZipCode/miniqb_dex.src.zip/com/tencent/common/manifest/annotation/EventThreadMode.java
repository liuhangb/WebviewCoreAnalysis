package com.tencent.common.manifest.annotation;

public class EventThreadMode
{
  public static final String ASYNCTHREAD = "ASYNCTHREAD";
  public static final String EMITER = "EMITER";
  public static final String MAINTHREAD = "MAINTHREAD";
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\common\manifest\annotation\EventThreadMode.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */