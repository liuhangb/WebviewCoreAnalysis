package com.tencent.common.plugin;

public abstract interface IDownloadClient
{
  public abstract void onDownloadNotify(String paramString1, String paramString2, boolean paramBoolean, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\common\plugin\IDownloadClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */