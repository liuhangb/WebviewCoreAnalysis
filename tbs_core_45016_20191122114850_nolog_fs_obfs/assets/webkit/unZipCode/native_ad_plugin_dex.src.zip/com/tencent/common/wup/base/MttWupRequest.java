package com.tencent.common.wup.base;

import com.tencent.common.http.MttRequestBase;

public class MttWupRequest
  extends MttRequestBase
{
  protected void fillCookies() {}
  
  protected void fillQHeaders() {}
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\common\wup\base\MttWupRequest.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */