package android.webview.chromium.tencent;

import android.webview.chromium.GraphicsUtils;

public class TencentGraphicsUtils
  extends GraphicsUtils
{
  public static long getDrawGLFunctionTable()
  {
    return 0L;
  }
  
  public static long getDrawSWFunctionTable()
  {
    return 0L;
  }
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\android\webview\chromium\tencent\TencentGraphicsUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */