package com.tencent.downloadprovider;

public class a
{
  public int a;
  public long a;
  public a a;
  public String a;
  
  public a()
  {
    this.jdField_a_of_type_ComTencentDownloadproviderA$a = a.d;
    this.jdField_a_of_type_Long = System.currentTimeMillis();
  }
  
  static enum a
  {
    static
    {
      jdField_a_of_type_ComTencentDownloadproviderA$a = new a("A", 0);
      b = new a("U", 1);
      c = new a("C", 2);
      d = new a("E", 3);
      jdField_a_of_type_ArrayOfComTencentDownloadproviderA$a = new a[] { jdField_a_of_type_ComTencentDownloadproviderA$a, b, c, d };
    }
    
    private a() {}
  }
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\downloadprovider\a.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */