package com.tencent.mtt.external.reader.base;

public class ReaderConstants
{
  public static final int ID_BTN_DOC_SEARCH = 1003;
  public static final int ID_BTN_PDF_OUTLINE = 1000;
  public static final int ID_BTN_PPT_PLAY_MODEL = 1002;
  public static final int ID_BTN_QQ_FILE_LIST = 1004;
  public static final int ID_BTN_TXT_READING_MODEL = 1001;
  public static final int ID_EVENT_EXTRA_MENU_GENERAL_EVENT = 10005;
  public static final String KEY_OUTLINE_DATA = "outlinedata";
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\mtt\external\reader\base\ReaderConstants.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */