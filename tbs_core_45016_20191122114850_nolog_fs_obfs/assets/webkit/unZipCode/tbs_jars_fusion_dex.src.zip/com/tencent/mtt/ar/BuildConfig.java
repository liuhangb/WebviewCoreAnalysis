package com.tencent.mtt.ar;

public final class BuildConfig
{
  public static final String APPLICATION_ID = "com.tencent.mtt.ar";
  public static final String BUILD_TYPE = "release";
  public static final boolean DEBUG = false;
  public static final String FLAVOR = "partner";
  public static final int VERSION_CODE = 1;
  public static final String VERSION_NAME = "1.0";
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\mtt\ar\BuildConfig.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */