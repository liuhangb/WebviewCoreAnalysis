package com.tencent.beacontbs.d;

import java.io.Serializable;

public abstract class c
  implements Serializable
{
  public abstract void a(a parama);
  
  public abstract void a(b paramb);
}


/* Location:              C:\Users\Administrator\Desktop\学习资料\dex2jar\dex2jar-2.0\classes-dex2jar.jar!\com\tencent\beacontbs\d\c.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       0.7.1
 */